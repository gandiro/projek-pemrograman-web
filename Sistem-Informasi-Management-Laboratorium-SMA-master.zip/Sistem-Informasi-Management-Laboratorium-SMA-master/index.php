<?php
require_once('layout/header.php');
require('config/db.php');
?>

<!-- BEGIN HOME -->
<section id="home" class="page">
	<div class="container">
		<div class="content cover text-center">
			<div class="row">

				<div class="col-lg-12" style="padding-top: 30px;">
					<label style="font-size:40px;">SISTEM INFORMASI LABORATORIUM KIMIA</label><br>
					<h3><label>SMAN 1 Madiun</label></h3>
				</div>
				<div class="col-lg-12" style="margin-top: 20px; padding-top: 30px;">
					<img src="gallery/Smasa.png" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END HOME -->

<?php require_once('layout/footer.php'); 	?>