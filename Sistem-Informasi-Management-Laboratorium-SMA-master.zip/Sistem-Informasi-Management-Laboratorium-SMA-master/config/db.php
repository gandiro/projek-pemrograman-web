<?php
	$conn = mysqli_connect("localhost","root","","siml")or die("Gagal Koneksi");
?>
